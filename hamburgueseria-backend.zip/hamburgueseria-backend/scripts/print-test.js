const fs = require('fs');
const EscPosEncoder = require('esc-pos-encoder');

const DEV = process.env.ESC_POS_DEV || '/dev/usb/lp1';

const enc = new EscPosEncoder();
const buf = enc
  .initialize()
  .align('center').bold(true).size(2, 2).line('🍔 OHAIO BURGER & COFFEE ☕')
  .bold(false).size(1, 1).line('---------------------------')
  .align('left').line('Ticket de prueba OK')
  .align('center').line('---')
  .line('¡Gracias por tu compra!')
  .cut('full')
  .encode();   // ⚠️ MUY IMPORTANTE

fs.writeFileSync(DEV, Buffer.from(buf));
console.log(`✅ Ticket enviado a ${DEV}`);

