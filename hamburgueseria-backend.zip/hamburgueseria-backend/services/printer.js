// services/printer.js
const fs = require('fs');
const EscPosEncoder = require('esc-pos-encoder');

// 👇 ruta del dispositivo (USB)
const DEV = process.env.ESC_POS_DEV || '/dev/usb/lp1';

// 👉 Chequeo de salud (solo verifica que el device existe y tiene permisos)
function printerHealth() {
  return new Promise((resolve) => {
    fs.access(DEV, fs.constants.W_OK, (err) => {
      if (err) {
        resolve({ ok: false, dev: DEV, error: err.message });
      } else {
        resolve({ ok: true, dev: DEV });
      }
    });
  });
}

// 👉 Impresión de pedido (estética con corte más abajo)
function printOrder(pedido) {
  return new Promise((resolve, reject) => {
    try {
      const enc = new EscPosEncoder();
      const buf = enc
        .initialize()

        // --- HEADER ---
        .align('center').bold(true).size(2, 2)
        .line('OHAIO - Pedido')
        .bold(false).size(1, 1)
        .line('---------------------------')


        .align('left').bold(true).size(2, 2)
        .line(`Cliente: ${pedido.cliente || 'Take Away'}`)

        // ---  PEDIDOS ---
        .align('left').bold(true).size(2, 2)
        .line('Pedidos:')
        .line((pedido.detalles || [])
          .map((item, i) => `${i + 1} ${item.producto} x${item.cantidad}`)
          .join('\n')
        )
        // --- DETALLES ---
        .line('')
        .bold(true)
        .line(pedido.notas ? `Notas: ${pedido.notas}` : '')

        // --- FOOTER ---
        .align('center')
        .line('---------------------------')
        .line('')
        .cut('full')
        .encode();

      fs.writeFileSync(DEV, Buffer.from(buf), null);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
}

module.exports = { printerHealth, printOrder };
