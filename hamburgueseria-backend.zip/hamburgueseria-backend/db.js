// db.js
module.exports = require('./config/db');
