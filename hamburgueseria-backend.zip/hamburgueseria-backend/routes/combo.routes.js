const express = require('express');
const router = express.Router();
const ComboController = require('../controllers/combo.controller');

router.get('/', ComboController.obtenerCombos);
router.get('/:id', ComboController.obtenerComboPorId);
router.post('/', ComboController.crearCombo);
router.put('/:id', ComboController.actualizarCombo);
router.delete('/:id', ComboController.eliminarCombo);

module.exports = router;
