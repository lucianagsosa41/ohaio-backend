// routes/pedido.routes.js
const express = require('express');
const { getPedidos, createPedido, putPedido, deletePedido } = require('../controllers/pedido.controller');
const { nextEstado } = require('../controllers/pedidos.ui.controller'); // si ya lo tenías

const router = express.Router();

// CRUD básico
router.get('/', getPedidos);       // GET    /api/pedidos
router.post('/', createPedido);    // POST   /api/pedidos
router.put('/:id', putPedido);     // PUT    /api/pedidos/:id
router.delete('/:id', deletePedido); // DELETE /api/pedidos/:id

// flujo de estado (opcional, si lo estás usando en el front)
router.patch('/:id/next', nextEstado); // PATCH /api/pedidos/:id/next

module.exports = router;
