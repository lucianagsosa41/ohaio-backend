const express = require('express');
const router = express.Router();
const controller = require('../controllers/hamburguesas.controller');

router.get('/', controller.getHamburguesas);
module.exports = router;
