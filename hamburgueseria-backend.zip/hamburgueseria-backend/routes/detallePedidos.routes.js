const express = require('express');
const router = express.Router();
const detallePedidosController = require('../controllers/detallePedidos.controller');

router.post('/', detallePedidosController.createDetallePedido);
router.get('/pedido/:pedidoId', detallePedidosController.getDetalleByPedidoId);

module.exports = router;
